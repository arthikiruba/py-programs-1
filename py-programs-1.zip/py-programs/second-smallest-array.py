#second smallest element in an array
size = int(input('Enter a size of an array : '))
arr = []

for i in range(size):
  element = int(input())
  arr.append(element)
  arr.sort()
print('The second smallest element is : ', arr[1])