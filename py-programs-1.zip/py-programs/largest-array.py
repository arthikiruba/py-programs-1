#largest element of an array
size = int(input('Enter a size of an array : '))
arr = []

for i in range(size):
  element = int(input())
  arr.append(element)
print('The largest element is : ', max(arr))